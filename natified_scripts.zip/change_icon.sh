#!/bin/sh

CONVERT_ARGS="-fuzz 10% -trim -alpha set -transparent #ffffff"

if [ $# -eq 1 ]
    then
        echo "[*] Recherche d'une icone pour $1"
elif [ $# -eq 2 ]
    then
        echo "[*] Téléchargement de l'icone ..."
        fn=$(wget -nv $2 2>&1 |cut -d\" -f2)
        echo "[*] Application de l'image $fn sur le logiciel $1"
        convert $fn $CONVERT_ARGS $1_icon.png
        rm $fn
        mv $1_icon.png ../share/icons/
fi
