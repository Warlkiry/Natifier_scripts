#!/usr/bin/env python3
#-*-encoding:utf-8*-

from json import loads as jsload
import sys

filepath = sys.argv[1]
with open(filepath, "r") as fichier:
    data = jsload(fichier.read())
print(data["name"])
