#!/bin/bash

echo "[*] Cloning url $1 with name $2"
read -p "[*] Appuyer sur Entrer pour continuer, CTRL+C pour annuler"
nativefier --single-instance --name "$2" $1 ./
./create_exec_bin.sh $2
echo "[*] Creating desktop shortcut ..."
cp ./$2-linux-x64/resources/app/icon.png ../share/icons/$2_icon.png
CLASSNAME=$(./extract_name.py ./$2-linux-x64/resources/app/package.json)
echo "#!/usr/bin/env xdg-open

[Desktop Entry]
Version=1.0
Type=Application
Terminal=false
Icon[fr_FR]=$2_icon
Name[fr_FR]=$2
StartupWMClass=$CLASSNAME
Exec=$HOME/.local/bin/$2
Comment[fr_FR]=$2 apps created with nativefier
Name=$2
Comment=$2 apps created with nativefier
Icon=$2_icon" > ../share/applications/$2.desktop
chmod 755 ../share/applications/$2.desktop
echo "[*] Done"
