#!/bin/bash

echo "[*] Purging $1 ..."
rm -r ./$1-linux-x64
rm ../bin/$1
rm ../share/icons/$1_icon.png
rm ../share/applications/$1.desktop
echo "[*] Done"
