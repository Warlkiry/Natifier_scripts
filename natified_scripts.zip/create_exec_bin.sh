#!/bin/bash

echo "[*] Creating executable for $1"

echo "#!/bin/bash
cd ~/.local/natified_apps/$1-linux-x64/
./$1" > ../bin/$1
chmod 755 ../bin/$1
echo "[*] Done"
